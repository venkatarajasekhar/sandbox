## make this version of pyqtgraph importable before any others
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
