.. pyqtgraph documentation master file, created by
   sphinx-quickstart on Fri Nov 18 19:33:12 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to the documentation for pyqtgraph 1.8
==============================================

Contents:

.. toctree::
    :maxdepth: 2

    introduction
    mouse_interaction
    how_to_use
    plotting
    images
    style
    region_of_interest
    graphicswindow
    parametertree
    internals
    apireference
    

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

