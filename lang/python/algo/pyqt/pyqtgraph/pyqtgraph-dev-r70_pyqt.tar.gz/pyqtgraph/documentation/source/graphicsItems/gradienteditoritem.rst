GradientEditorItem
==================

.. autoclass:: pyqtgraph.GradientEditorItem
    :members:

    .. automethod:: pyqtgraph.GradientEditorItem.__init__

