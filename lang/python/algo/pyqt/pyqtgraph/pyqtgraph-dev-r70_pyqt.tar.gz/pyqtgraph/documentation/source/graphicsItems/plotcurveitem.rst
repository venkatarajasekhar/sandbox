PlotCurveItem
=============

.. autoclass:: pyqtgraph.PlotCurveItem
    :members:

    .. automethod:: pyqtgraph.PlotCurveItem.__init__

