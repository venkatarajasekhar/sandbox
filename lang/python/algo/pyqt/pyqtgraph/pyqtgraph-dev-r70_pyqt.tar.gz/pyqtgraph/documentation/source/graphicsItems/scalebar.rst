ScaleBar
========

.. autoclass:: pyqtgraph.ScaleBar
    :members:

    .. automethod:: pyqtgraph.ScaleBar.__init__

