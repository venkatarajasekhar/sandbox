Region-of-interest controls
===========================

Slicing Multidimensional Data
-----------------------------

Linear Selection and Marking
----------------------------

2D Selection and Marking
------------------------




- translate / rotate / scale
- highly configurable control handles
- automated data slicing
- linearregion, infiniteline
