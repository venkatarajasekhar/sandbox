Rapid GUI prototyping
=====================

 - parametertree
 - dockarea
 - flowchart
 - canvas
