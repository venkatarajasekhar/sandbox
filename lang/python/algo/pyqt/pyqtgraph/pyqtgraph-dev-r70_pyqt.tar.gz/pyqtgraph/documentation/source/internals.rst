Internals - Extensions to Qt's GraphicsView
================================

* GraphicsView
* GraphicsScene (mouse events)
* GraphicsObject
* GraphicsWidget
* ViewBox

